import logo from './logo.svg';
import './App.css';
import { Box } from '@mui/system';
import Layout from './Components/Layout';

function App() {
  return (
    <Box>
      <Layout />
    </Box>
  );
}

export default App;
