export const DataOne = [
    {
        name:"Accès à notre base de données de réseaux WiFis aux Antilles",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Créez des QR Codes WiFi",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Partagez votre réseau WiFi avec votre entourage facilement",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Connectez-vous à des réseaux WiFis dans plus de 100 pays dans le monde",
        image:"./assets/vector/IconCorrect.png",
    },

]

export const DataTwo = [
    {
        name:"Accès à notre base de données de réseaux WiFis aux Antilles",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Créez des QR Codes WiFi",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Partagez votre réseau WiFi avec votre entourage facilement",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Connectez-vous à des réseaux WiFis dans plus de 100 pays dans le monde",
        image:"./assets/vector/IconCorrect.png",
    },
    {
        name:"Connexions illimitées",
        image:"./assets/vector/IconCorrect.png",
    },
]