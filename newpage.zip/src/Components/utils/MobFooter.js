import React from 'react'
import { Box } from '@mui/system'
import { Grid, Typography,IconButton } from "@mui/material";
import { Facebook, FacebookOutlined, Instagram, LinkedIn, Twitter } from "@mui/icons-material";



function MobFooter() {
    return (
        <Box
      sx={{
        padding: {
          xs: "55px 30px",
          sm: "32px 30px",
          md: "5% 45px",
          lg: "6% 45px",
        },
        margin: "auto",
        backgroundColor: "#53389E",
      }}
    >
        <Grid xs={12} sx={{ mt:2 }}>
        <Grid item md={12} lg={12} container>
        <img src="./assets/Footer/VectorFooter.png" />
        <Typography
          variant="h6"
          component="div"
          sx={{
            marginLeft: "13px",
            marginTop: "10px",
            fontSize: "32px",
            color: "#fff",
            fontFamily: "Inter",
            fontWeight: "700",
            lineHeight: "40px",
          }}
        >
          Weezee
        </Typography>
      </Grid>
      <Box sx={{ width: "320px" }}>
        <Typography
          sx={{
            marginTop: "40px",
            fontSize: "16px",
            color: "#D6BBFB",
            fontFamily: "Inter",
            fontWeight: "normal",
            lineHeight: "24px",
          }}
        >
          WiFi illimité à l’extérieur, à prix cassé !
        </Typography>
      </Box>
      <a href="#" style={{ textDecoration:"none"}}>
          <Typography
            sx={{
              color: "#D6BBFB",
              
              marginTop: "32px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
              width:"100%",
            }}
          >
            Le concept
          </Typography>
        </a>
        <a href="#" style={{ textDecoration:"none"}}>
          <Typography
            sx={{
              color: "#D6BBFB",
              
              marginTop: "32px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
              width:"100%",
            }}
          >
            L’application
          </Typography>
        </a>
        <a href="#" style={{ textDecoration:"none"}}>
          <Typography
            sx={{
              color: "#D6BBFB",
              marginTop: "32px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
              width:"100%",
            }}
          >
            Weezee Map
          </Typography>
        </a>
        <a href="#" style={{ textDecoration:"none"}}>
          <Typography
            sx={{
              color: "#D6BBFB",
              
              marginTop: "32px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
              width:"100%",
            }}
          >
            Nos Tarifs
          </Typography>
        </a>
        <a href="#" style={{textDecoration: "none", }}>
          <Typography
            sx={{
              color: "#D6BBFB",
              marginRight: "33px",
              fontSize: "16px",
              lineHeight: "24px",
              marginTop:"10px",
              underlineColor:"#53389E",
            marginTop:"60px",

            }}
          >
            © 2021 Weezee. All rights reserved.
          </Typography>
        </a>
        <Box
          sx={{
            width: "200px",
            justifyContent: "space-between",
            display: "flex",
            color:"#fff",
            marginTop:"30px",
          }}
        >
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <Twitter />
          </IconButton>
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <LinkedIn />
          </IconButton>
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <FacebookOutlined />
          </IconButton>
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <Instagram />
          </IconButton>
        </Box>
        </Grid>
        </Box>
    )
}

export default MobFooter
