import React from 'react'

function MobNav() {
  return (
    <div>
      
    </div>
  )
}

export default MobNav
