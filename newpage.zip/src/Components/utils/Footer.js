import React from "react";
import { Box } from "@mui/system";
import { Grid, Typography,IconButton } from "@mui/material";
import { desktopNavbar } from "../Styles/NavStyle";
import { Facebook, FacebookOutlined, Instagram, LinkedIn, Twitter } from "@mui/icons-material";

function Footer() {
  const classes = desktopNavbar();
  return (
    
    <Box
      sx={{
        padding: {
          xs: "16px 12px",
          sm: "15px 12px",
          sm: "5% 45px",
          lg: "6% 45px",
        },
        margin: "auto",
        backgroundColor: "#53389E",
      }}
    >
      <Grid item md={12} lg={12} container>
        <img src="./assets/Footer/VectorFooter.png" />
        <Typography
          variant="h6"
          component="div"
          sx={{
            marginLeft: "13px",
            marginTop: "10px",
            fontSize: "32px",
            color: "#fff",
            fontFamily: "Inter",
            fontWeight: "700",
            lineHeight: "40px",
          }}
        >
          Weezee
        </Typography>
      </Grid>
      <Box sx={{ width: "320px" }}>
        <Typography
          sx={{
            marginTop: "40px",
            fontSize: "16px",
            color: "#D6BBFB",
            fontFamily: "Inter",
            fontWeight: "normal",
            lineHeight: "24px",
          }}
        >
          WiFi illimité à l’extérieur, à prix cassé !
        </Typography>
      </Box>
      <Grid item md={12} lg={12} sx={{ marginTop: "32px", overflow: "auto" }}>
        <a href="#">
          <Typography
            sx={{
              color: "#D6BBFB",
              float: "left",
              marginRight: "33px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
            }}
          >
            Le concept
          </Typography>
        </a>
        <a href="#">
          <Typography
            sx={{
              color: "#D6BBFB",
              float: "left",
              marginRight: "33px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
            }}
          >
            L’application
          </Typography>
        </a>
        <a href="#">
          <Typography
            sx={{
              color: "#D6BBFB",
              float: "left",
              marginRight: "33px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
            }}
          >
            Weezee Map
          </Typography>
        </a>
        <a href="#">
          <Typography
            sx={{
              color: "#D6BBFB",
              float: "left",
              marginRight: "33px",
              textDecoration: "none",
              fontSize: "16px",
              lineHeight: "24px",
            }}
          >
            Nos Tarifs
          </Typography>
        </a>
      </Grid>
      <Grid item container md={12} xs={12} sx={{ marginTop: "62px", border:"2px solid orange" ,justifyContent:"space-between"}}>
              
        <a href="#" style={{textDecoration: "none", }}>
          <Typography
            sx={{
              color: "#D6BBFB",
              marginRight: "33px",
              fontSize: "16px",
              lineHeight: "24px",
              marginTop:"10px",
              underlineColor:"#53389E"
            }}
          >
            © 2021 Weezee. All rights reserved.
          </Typography>
        </a>
        <Box
          sx={{
            width: "200px",
            justifyContent: "space-between",
            display: "flex",
            color:"#fff",
          }}
        >
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <Twitter />
          </IconButton>
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <LinkedIn />
          </IconButton>
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <FacebookOutlined />
          </IconButton>
          <IconButton aria-label="delete" sx={{ color:"#fff"}}>
            <Instagram />
          </IconButton>
        </Box>
      </Grid>
    </Box>
  );
}

export default Footer;
